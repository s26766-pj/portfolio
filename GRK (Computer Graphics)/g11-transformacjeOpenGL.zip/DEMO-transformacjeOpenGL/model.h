#ifndef MODEL_H
#define MODEL_H

typedef struct{
    float position[4];
    float polor[4];
} ColorVertex;


class Model{
public:
    Model();
};

#endif // MODEL_H
